import { Injectable, Component, OnInit} from '@angular/core';
import { App, NavController } from 'ionic-angular';
import { Http} from '@angular/http';
import * as moment from 'moment';
import {AlarmPage} from "../alarm/alarm";
import {AbPage} from "../ab/ab";
import { AppServiceProvider } from '../../providers/app-service/app-service';
import {isUndefined} from "ionic-angular/util/util";


@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
@Injectable()
export class ContactPage implements OnInit{
  day: any;
  diday: any;
  month:any;
  time:any;
  data: any;
  api: string = this.appServiceProvider.getAPI()+ '/startseite/'+this.appServiceProvider.getID()+'/'+moment().format('YYYY-MM-DD HH:mm:ss');
  LoginData: any = {sozialNr: '', password: '',error: ''};
  tasks: any[];
  notasks: boolean;
  error: 'Hier sind keine Tasks';
  hide: string = 'hidden';

  interval: any;

  public klick(){
    this.app.getRootNav().setRoot(AbPage);
  }

  public logout(){
    if(this.hide=='hidden'){
      this.hide='abmelden';
    }else{
      this.hide='hidden';
    }
  }
  TheTime(){
    this.day = moment().lang("de").format('dddd');
    this.diday = moment().lang("de").format('DD');
    this.month = moment().lang("de").format('MMMM');
    this.time = moment().format('H:mm');

    if(this.notasks==false) {
      if (this.time == this.tasks[0].start) {
        clearInterval(this.interval);
        this.app.getRootNav().setRoot(AlarmPage);
      }
    }


  }
  ngOnInit() {

    console.log('API:' + this.api);
    this.http
        .get(this.api)
        .toPromise()
        .then(data => {
          console.log(data);
          this.tasks = data.json();
          if(isUndefined(this.tasks) || this.tasks == []){
            console.log(this.tasks[0].start);
            this.notasks = true;
          }
          else {
            console.log(this.tasks);
            for (let task of this.tasks){
              task.link = 'assets/imgs' + task.link;
              var splited = task.start.split(' ');
              var split2 = splited[1].split(':');
              task.start = split2[0] + ':' + split2[1];
            }
            this.notasks = false;
            //console.log(this.tasks);
            this.appServiceProvider.setNextTasks(this.tasks[0]);
          }


        })
        .catch(() => {});

    this.interval = setInterval(()=> {
      this.TheTime(); },1000);


  }






  constructor(public navCtrl: NavController, private http: Http, private app:App, private appServiceProvider: AppServiceProvider) {}

}
