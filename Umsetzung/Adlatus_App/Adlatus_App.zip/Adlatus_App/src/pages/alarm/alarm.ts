import { Injectable, Component, OnInit} from '@angular/core';
import {App, NavController } from 'ionic-angular';
import {ContactPage} from "../contact/contact";
import { Vibration } from '@ionic-native/vibration';
import { NativeAudio } from '@ionic-native/native-audio';
import { AppServiceProvider } from '../../providers/app-service/app-service';

/**
 * Generated class for the AlarmPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-alarm',
  templateUrl: 'alarm.html',
})
@Injectable()
export class AlarmPage  implements OnInit{
  nextTask: any;

  ngOnInit(){
    console.log('drin');
    this.vibration.vibrate(10000);
    this.nativeAudio.loop('wecker');
  }
  public onClickNo():void{
    this.app.getRootNav().setRoot(ContactPage);
  }

  public onClickYes():void{
    this.app.getRootNav().setRoot(ContactPage);
  }
  constructor(public navCtrl: NavController, private app:App, private vibration: Vibration, private appServiceProvider: AppServiceProvider, private nativeAudio: NativeAudio) {
    this.nativeAudio.preloadSimple('wecker', '../../assets/alarm.mp3');

    this.nextTask= this.appServiceProvider.getNextTask()
    console.log(this.nextTask);
  }

}
