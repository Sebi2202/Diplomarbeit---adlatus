import { App, NavController} from 'ionic-angular';
import { Injectable, Component} from '@angular/core';
import { AppServiceProvider } from '../../providers/app-service/app-service';
import { Http, Headers} from '@angular/http';
// Observable class extensions
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';

// Observable operators
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import {ContactPage} from "../contact/contact";


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
@Injectable()
export class HomePage {

  ret:boolean;
  data: any;
  LoginData: any = {sozialNr: '', password: '',error: ''};
  ID: number;


  constructor(private http: Http, private nav: NavController, private app:App, private appServiceProvider: AppServiceProvider) {
  }

  public createAccount() {
    this.nav.push('RegisterPage');
  }


  getData($url: any){
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');


    let data = {
      sozialNr: this.LoginData.sozialNr,
      password: this.LoginData.password
    };
    let ret;

    this.http
        .post($url, JSON.stringify(data), {headers: headers})
        .toPromise()
        .then(data => {
          ret= data.json().angenommen;
          if(ret){
            this.appServiceProvider.setID(data.json().id);
            this.app.getRootNav().setRoot(ContactPage);
          }
          else{
            this.LoginData.error="Logindaten nicht bekannt";
          }
        })
        .catch(() => {});



  }


  public getID(){
    return this.ID;
  }

  public login() {
    let api= this.appServiceProvider.getAPI()+'/login';
    this.getData(api);
  }

}
