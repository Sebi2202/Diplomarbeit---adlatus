import { Component } from '@angular/core';
import { App, IonicPage, NavController, NavParams } from 'ionic-angular';
import {ContactPage} from "../contact/contact";
import {HomePage} from "../home/home";

/**
 * Generated class for the AbPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-ab',
  templateUrl: 'ab.html',
})
export class AbPage {

  constructor(public navCtrl: NavController, private app:App, public navParams: NavParams) {
  }

  public onClickNo(){
    this.app.getRootNav().setRoot(ContactPage);
  }

  public onClickYes(){
    this.app.getRootNav().setRoot(HomePage);
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AbPage');
  }

}
