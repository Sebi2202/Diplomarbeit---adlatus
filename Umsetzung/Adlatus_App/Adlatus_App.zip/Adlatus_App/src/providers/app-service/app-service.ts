import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the AppServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class AppServiceProvider {
  ID: number;
  nexttask: any[];
  api: string = 'http://10.14.20.21:8000/api';


  constructor(public http: HttpClient) {
    console.log('Hello AppServiceProvider Provider');
  }

  public setID(id){
    this.ID = id;
  }

  public getID(){
    return this.ID;
  }

  public setNextTasks(tasks){
    this.nexttask = tasks;
  }

  public getAPI() {
    return this.api;
  }

  public getNextTask(){
    return this.nexttask;
  }

}
